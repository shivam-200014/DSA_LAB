#include<iostream>
using namespace std;
#include<stdio.h>

int main()
{
    char str[10];
    int a[10];
        scanf("%s",&str);
        cout<<str;
}