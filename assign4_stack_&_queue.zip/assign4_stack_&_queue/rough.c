#include<stdio.h>

int main()
{
    char str[]="viking's";
    char *ptr=str;
    printf("%p\t%s",ptr,ptr);

}